# Check function
#
# @param x Vector.
# @param tau Double.
#
# @return Vector. \eqn{x\[\tau-I(x<0)\]}
#' @export
#
check_function <- function(x,tau){
  return(x*(tau-(x<=0)))
}

# Subgradient of quantile check function
#
# @param x Double.
# @param tau Double.
#
# @return Double tau-I(x<=0).
#' @export
psi_function <- function(x,tau){
  return(tau-(x<=0))
}



# Compute the bandwidth (i.e. \eqn{h}) for QR
#
# @param n Int. Sample size.
# @param tau Double. Single quantile.
#
# @return Vector. Two bandwidths \eqn{h_{HS}} and \eqn{h_{B}}, i.e. \eqn{(h_{HS},h_{B})}.
#' @export
#'
h_compute <- function(n,tau){

  h_B <- n^(-1/5)*((4.5*dnorm(qnorm(tau))^4)/(2*qnorm(tau)^2+1)^2)^(1/5)
  h_HS <- n^(-1/3)*qnorm(1-0.05/2)^(2/3)*((1.5*dnorm(qnorm(tau))^2)/(2*qnorm(tau)^2+1)^2)^(1/3)
  return(c(h_B,h_HS))
}


#' Conditional quantile function of \eqn{Y_t}
#'
#' Conditional quantile function of \eqn{Y_t}, i.e. \eqn{Q_\tau(y_t|\mathcal{F}_{t-1})}.
#'
#' @param parm Vector. Parameter vector (3-dim), i.e. \eqn{\left(\omega(\tau),\alpha_1(\tau),\beta_1(\tau)\right)^\prime}.
#' @param Y Vector. Data.
#'
#' @return Vector. \eqn{\left(Q_\tau(y_1|\mathcal{F}_{0}),\ldots,Q_\tau(y_N|\mathcal{F}_{N-1})\right)^\prime}.
#' @export
#'
q_y <- function(parm,Y){
  N <- length(Y)
  q <- arch_fft(cst = parm[1],epsilon = Y[1:(N)],lambda = parm[2]*parm[3]^(1:(N)-1)) # length N-1
  return(q)
}

#' Transformation function in CQR
#'
#' @param parm_CQR Vector. Parameter vector (4-dim), i.e. \eqn{(a_0,a_1,b_1,\lambda)^\prime}.
#' @param tau Vector. Observations.
#'
#' @return Vector. Transformed parameter vector (3-dim), i.e. \eqn{(a_0Q_{\lambda}(\lambda)/(1-b_1),a_1Q_{\lambda},b_1)^\prime}.
#' @export
#'
g_tau <- function(parm_CQR,tau){
  parm_CQR_g <- array(dim = c(3))
  parm_CQR_g[1] <- parm_CQR[1]/(1-parm_CQR[3])*Q_tau_function(tau,parm_CQR[4])
  parm_CQR_g[2] <- parm_CQR[2]*Q_tau_function(tau,parm_CQR[4])
  parm_CQR_g[3] <- parm_CQR[3]
  return(parm_CQR_g)
}

# Fast Discrete Fourier Transform (FFT) for ARCH(\eqn{\infty}) models
#
# This function provides a fast algorithm to ARCH(\eqn{\infty}) with methodology in Nielsen and Noël(2020).
#
# @param cst Double. \eqn{\omega(\tau)}.
# @param epsilon Vector. \eqn{(Y_1,Y_2,...,Y_{N-1})}
# @param lambda Vector. \eqn{\alpha_1(\tau)(1,\beta_1(\tau),...,\beta_1^{N-2}(\tau))}, where \eqn{N} is the total number of observations.
#
# @return vector. \eqn{\left(\omega(\tau)+\alpha_1(\tau)\sum_{j=1}^{1}\beta_1^{j-1}(\tau)|Y_{t-j}|,...,\omega(\tau)+\alpha_1(\tau)\sum_{j=1}^{N-1}\beta_1^{j-1}(\tau)|Y_{t-j}|\right)}
#' @export
#
#
# @references Nielsen, M. Ø., and Noël, A. (2021). To infinity and beyond: Efficient computation of ARCH(\eqn{\infty}) models. *Journal of Time Series Analysis*, 42, 338-354.
#
arch_fft <- function(cst, epsilon, lambda){
  iT <- length(epsilon)
  np2 <- nextn(2*iT-1, 2)
  sigma2_arch <- fft(fft(c(lambda, rep(0, np2-iT))) * fft(c(abs(epsilon), rep(0, np2-iT))), inverse = T) / np2;
  sigma2_arch <- cst + sigma2_arch[1:iT]
  return(Re(sigma2_arch))
}

# Estimate GARCH model for initial value
#
# This function is used to provide a reasonable initial value for QR based on fitting a GARCH model with normal innovation term. For detail, see \code{fit1_optim}.
#
# @param Y Vector. Data.
# @param fixTau Vector. Multiple quantile levels.
#
# @return A list includes initial values for QR at multiple quantile levels.
#' @export
#'
Init_par <- function(Y,fixTau){
  r <- sqrt(abs(Y))*((Y>=0)-(Y<0))
  spec=ugarchspec(variance.model = list(model = "sGARCH", garchOrder = c(1, 1)),
                  mean.model = list(armaOrder = c(0, 0),include.mean = FALSE),
                  distribution.model = "norm")
  garch<-ugarchfit(spec = spec, data = r, solver = 'hybrid', fit.control = list(stationarity = 1))
  res <- residuals(garch,standardize=T)
  Q_tau <- sapply(fixTau, function(x) quantile((res)^2*((res>0)-(res<=0)),x))
  return(list("GARCH_par" = garch@fit$coef,"Q_tau"=Q_tau))
}
