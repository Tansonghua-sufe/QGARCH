# Quantile function for Tukey-lambda distribution with a shape parameter lambda
#
#
# @param tau Double. Specific quantile level.
# @param lambda Double. Shape parameter.
#
# @return Double. Quantile value for Tukey-lambda distribution with a shape parameter lambda
#
Q_tau_function <- function(tau,lambda){
  if(lambda==0){
    return(log(tau/(1-tau)))
  }else{
    return((tau^lambda-(1-tau)^lambda)/lambda)
  }
}

# The derivative of quantile function of Tukey-lambda distribution
#
# @param tau Double. Specific quantile level.
# @param lambda Double. Shape parameter.
#
# @return Double. The derivative of quantile function for Tukey-lambda distribution
#
#
Q_tau_dot_function <- function(tau,lambda){
  if(lambda==0){
    return((log(tau)*log(tau)-log(1-tau)*log(1-tau))/2)
  }else{
    return(((tau^lambda)*(lambda*log(tau)-1)-((1-tau)^lambda)*(lambda*log(1-tau)-1))/(lambda^2))
  }
}

# The second derivative of quantile function for Tukey-lambda distribution
#
# @param tau Double. Specific quantile level.
# @param lambda Double. Shape parameter.
#
# @return Double. The second derivative of quantile function for Tukey-lambda distribution
#
#
Q_tau_dotdot_function <- function(tau,lambda){
  if(lambda==0){
    return(2*((log(tau)^3)-(log(1-tau)^3))/6)
  }else{
    return((tau^lambda*((lambda*log(tau)-1)^2+1)-((1-tau)^lambda)*((lambda*log(1-tau)-1)^2+1))/(lambda^3))
  }
}

#' The loss function of CQR
#'
#' @param parm 4-dim vector. \eqn{(a_0,a_1,b_1,\lambda)^\prime}.
#' @param Y Vector. Data.
#' @param w Vector. Self-weights.
#' @param tau Vector. Composite quantile levels.
#'
#' @return Double. The loss of CQR given a parameter vector
#'
#' @export
#'
Loss_CQR <- function(parm,Y,w,tau){
  N <- length(Y)
  K <- length(tau)

  Q_tau <- Q_tau_function(tau,parm[4])
  b <- parm[2]*parm[3]^(1:(N-1)-1)
  h_t <- arch_fft(cst = parm[1]/(1-parm[3]),epsilon = Y[1:(N-1)],lambda = b)

  l <- matrix(rep(Y[2:N],K),nrow = N-1,ncol = K)-h_t%*%t(Q_tau)

  x <- rep(Y[1],K)-parm[1]/(1-parm[3])*Q_tau
  loss <- w[1]*sum(x*(tau-1*(x<0)))+sum(matrix(rep(w[2:N],K),nrow = N-1,ncol = K)*l*(matrix(rep(tau,each=N-1),nrow = N-1,ncol = K)-1*(l<0)))

  return(loss)
}

#' The derivative of CQR loss function
#'
#' @param parm Vector (4-dim). \eqn{(a_0,a_1,b_1,\lambda)^\prime}.
#' @param Y Vector. Data
#' @param w Vector. Self-weights.
#' @param tau Vector. Composite quantile levels.
#'
#' @return Vector. The vector of the gradient of loss function for self-weighted CQR estimation given a parameter vector.
#'
#' @export
#'
Loss_CQR_gr <- function(parm,Y,w,tau){
  N <- length(Y)
  K <- length(tau)

  Q_tau <- Q_tau_function(tau,parm[4])
  Q_tau_dot <- Q_tau_dot_function(tau = tau,lambda = parm[4])

  b <- parm[3]^(1:(N-1)-1)
  sum_term <- arch_fft(cst = 0,epsilon = Y[1:(N-1)],lambda = b)
  h_t <- parm[1]/(1-parm[3])+parm[2]*sum_term
  h_t <- c(parm[1]/(1-parm[3]),h_t)
  h_t_dot1 <- rep(1/(1-parm[3]),N)
  h_t_dot2 <- sum_term
  h_t_dot2 <- c(0,h_t_dot2)
  b1 <- (1:(N-2))*parm[3]^(1:(N-2)-1)
  h_t_dot3 <- parm[1]/(1-parm[3])^2+parm[2]*arch_fft(cst = 0,epsilon = Y[1:(N-2)],lambda = b1)
  h_t_dot3 <- c(parm[1]/(1-parm[3])^2,parm[1]/(1-parm[3])^2,h_t_dot3)

  l <- matrix(rep(Y,K),nrow = N,ncol = K)-h_t%*%t(Q_tau)
  l_M2 <- matrix(rep(tau,each = N),nrow = N,ncol = K)-1*(l<0)
  gr <- c(sum(-matrix(rep(w,K),nrow = N,ncol = K)*l_M2*matrix(rep(h_t_dot1,K),nrow = N,ncol = K)*matrix(rep(Q_tau,each = N),nrow = N,ncol = K)),
          sum(-matrix(rep(w,K),nrow = N,ncol = K)*l_M2*matrix(rep(h_t_dot2,K),nrow = N,ncol = K)*matrix(rep(Q_tau,each = N),nrow = N,ncol = K)),
          sum(-matrix(rep(w,K),nrow = N,ncol = K)*l_M2*matrix(rep(h_t_dot3,K),nrow = N,ncol = K)*matrix(rep(Q_tau,each = N),nrow = N,ncol = K)),
          sum(-matrix(rep(w,K),nrow = N,ncol = K)*l_M2*matrix(rep(h_t,K),nrow = N,ncol = K)*matrix(rep(Q_tau_dot,each = N),nrow = N,ncol = K)))
  return(gr)
}

#' An optimization function of self-weighted CQR estimation given fixed initial value.
#'
#' This function provide an optimization function of self-weighted CQR with a fixed initial value.
#' Either method, derivative optimization using \code{stats::optim()} or derivative-free optimization using \code{dfoptim::hjkb()}, can be used.
#' To avoid error or non-convergence in optimization, we add an innovation to the initial value and re-optimize this problem.
#' If the optimization fails on initial value,
#' a more complicated optimization function \code{fit2_optim_grid} based on greedy search.
#'
#' @param par Vector. Initial value for optimization.
#' @param Y Vector. Data.
#' @param w Vector. Self-weights.
#' @param tau Vector. Composite quantile levels.
#' @param lower Vector. Lower bound for parameter vector. The default value is c(1e-9,1e-3,1e-3,NA).
#' @param upper Vector. Upper bound for parameter vector. The default value is c(NA,NA,1-1e-3,NA).
#' @param method Character. If \code{method="optim"}, derivative optimization by \code{stats::optim()} is used. If \code{method="dfoptim"}, derivative-free optimization by \code{dfoptim::hjkb()} is used.
#' @param iter_max_1 Int. If the optimization function does not converge or the parameter vector is at the boundary, then re-optimize. Maximum number of repetitions of this step is \code{iter_max_1}. The default is 10.
#' @param iter_max_2 Int. If the condition in \code{iter_max_1} cannot be satisfied, then relax the boundary condition and estimate again. Maximum number of repetitions of this step is \code{iter_max_2-iter_max_1}. The default of \code{iter_max_2} is 20.
#' @param seed Double. Random seed is used to generate an innovation to perturb the initial value.
#'
#' @return A list of optimization result returned from the \code{optim()} function.
#' @export
#'
fit2_optim <-function(par,Y,w,tau,lower = c(1e-9,1e-3,1e-3,-Inf),upper = c(+Inf,1-1e-3,1-1e-3,+Inf),method="optim",iter_max_1=10,iter_max_2=20,seed=1234){
  set.seed(seed)
  if(method=="dfoptim"){
    fit0 <- try(hjkb(par = par,fn = Loss_CQR,Y=Y,w=w,tau=tau,lower = lower,upper = upper),silent = T)
  }else{
    fit0 <- try(optim(par = par,fn = Loss_CQR,gr=Loss_CQR_gr,Y=Y,w=w,tau=tau,method = "L-BFGS-B",lower = lower,upper = upper),silent = T)
  }

  k <- 0
  convergence <- 0
  if("try-error"%in% class(fit0)){
    convergence <- 1
  }else{
    if(fit0$convergence!=0 | any(c(fit0$par<=lower,fit0$par>=upper))){
      convergence <- 1
    }
  }
  while (convergence!=0 && k<iter_max_1){
    k <- k+1
    par_k <- par+runif(4,-0.1,0.1)

    if(method=="dfoptim"){
      fit0 <- try(hjkb(par = par_k,fn = Loss_CQR,Y=Y,w=w,tau=tau,lower = lower,upper = upper),silent = T)
    }else{
      fit0 <- try(optim(par = par_k,fn = Loss_CQR,gr=Loss_CQR_gr,Y=Y,w=w,tau=tau,method = "L-BFGS-B",lower = lower,upper = upper),silent = T)
    }
    convergence <- 0
    if("try-error"%in% class(fit0)){
      convergence <- 1
    }else{
      if(fit0$convergence!=0 | any(c(fit0$par<=lower,fit0$par>=upper))){
        convergence <- 1
      }
    }
  }


  while (convergence!=0 && k<iter_max_2){
    k <- k+1
    par_k <- par+runif(4,-0.1,0.1)

    if(method=="dfoptim"){
      fit0 <- try(hjkb(par = par_k,fn = Loss_CQR,Y=Y,w=w,tau=tau,lower = lower,upper = upper),silent = T)
    }else{
      fit0 <- try(optim(par = par_k,fn = Loss_CQR,Y=Y,w=w,tau=tau,method = "L-BFGS-B",lower = lower,upper = upper),silent = T)
    }
    convergence <- 0
    if("try-error"%in% class(fit0)){
      convergence <- 1
    }else{
      if(fit0$convergence!=0){
        convergence <- 1
      }
    }
  }

  if(convergence!=0){fit0 <- fit2_optim_grid(Y = Y,w = w,tau = tau)}

  return(fit0)
}

#' An optimization function of self-weighted CQR given multiple initial values
#'
#' This function extends the optimization function \code{fit2_optim()} given with a single initial value to multiple initial values.
#' The method is based on greedy algorithm. In this framework, we start by listing all the possible parameter values with interval \code{1/D}.
#' Then the loss function is evaluated at all points, and the points with the least loss are selected as the starting points for our optimization.
#'
#'
#' @param Y Vector. Data.
#' @param w Vector. Self-weight.
#' @param tau Vector. Composite quantile level.
#' @param lower Vector. Lower bound for parameter vector. The default value is \code{c(1e-9,1e-3,1e-3,+Inf)}.
#' @param upper Vector. Upper bound for parameter vector. The default value is \code{c(-Inf,-Inf,1-1e-3,-Inf)}.
#' @param D Int. \code{1/D} is the interval for partition. The default value is 10.
#' @param num_best Int. The number of the selected points. The default value is 10.
#'
#' @return A list of optimization result returned from the \code{optim()} or \code{hjkb()} function.
#' @export
#'
fit2_optim_grid <-function(Y,w,tau,lower = c(1e-9,1e-3,1e-3,-Inf),upper=c(+Inf,1-1e-3,1-1e-3,+Inf),D=10,num_best=10){

  lambda <- rep((1-D):(-1)/D,each = (D-1)^3)
  beta <- rep(rep(1:(D-1)/D,each = (D-1)^2),times=(D-1))
  alpha <- rep(rep(1:(D-1)/D,each = (D-1)),times = (D-1)^2)
  omega <- rep(1:(D-1)/D,times = (D-1)^3)

  par <- matrix(c(omega,alpha,beta,lambda),nrow = (D-1)^3*(D-1),ncol = 4)
  loss_par <- apply(par,1,function(x) Loss_CQR(parm=x,Y=Y,w=w,tau = tau))
  index1 <- order(loss_par)
  if(length(index1)>num_best){index1 <- index1[1:num_best]}

  fun <- function(x){
    k <- 0
    fit0 <- try(optim(par = x,fn = Loss_CQR,gr = Loss_CQR_gr,Y=Y,w=w,method = "L-BFGS-B",tau = tau,lower = lower,upper=upper),silent = T)
    convergence <- 0
    if("try-error"%in%class(fit0)==T){
      convergence <- 1
    }else{
      if(fit0$convergence!=0){
        convergence <- 1
      }
    }

    if(convergence==1){
      return(NA)
    }else{
      return(fit0$value)
    }

  }

  l <- apply(par[index1,],1,fun)
  index2 <- which.min(l)

  fit0 <- optim(par = par[index1[index2],],fn = Loss_CQR,gr = Loss_CQR_gr,Y=Y,w=w,tau=tau,method = "L-BFGS-B",lower = lower,upper=upper)

  return(fit0)
}

