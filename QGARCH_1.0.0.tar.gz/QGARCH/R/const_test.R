#' The Cramér-von Misses (CvM) test
#'
#' The Cramér-von Misses (CvM) test for constant persistence coefficient
#'
#' @details
#' This function provides a test for constant persistence coefficient.
#'
#' \eqn{H_0:} for all \eqn{\tau \in \mathcal{T}, R\theta(\tau)=\beta_1} against \eqn{H_1:} there exist \eqn{\tau \in \mathcal{T},R\theta(\tau)\neq \beta_1},
#'
#' where \eqn{R=(0,0,1)} is a row vector, and \eqn{\beta_1\in (0,1)} is an unknown constant independent of \eqn{\tau}.
#' If the null hypothesis \eqn{H_0} holds, then \eqn{\beta_1(\tau)} does not vary cross quantiles.
#'
#' Define the inference process \eqn{\nu_n(\tau)=R\left(\tilde{\theta}_{wn}(\tau)-\int_\mathcal{T}\tilde{\theta}_{wn}(\tau)d\tau\right)}.
#' To test \eqn{H_0}, the CvM test statistic is constructed as follows
#'
#' \eqn{S_n=n\int_\mathcal{T} \nu_n^2(\tau)d\tau}.
#'
#' @param Y Vector. Data.
#' @param w Vector. Self-weights.
#' @param tau_multi Vector(\eqn{k}-dim). Multiple quantile levels.
#' @param parm_multi Matrix(\eqn{k\times 3}). Each row in \code{parm_multi} represents a parameter estimate in corresponding quantile levels.
#' @param Omega_1_multi Array(\eqn{k\times 3\times 3}). Each \code{Omega_1_multi[i,,]} \code{i=1,...,k}  represents The estimate of \eqn{\tilde{\Omega}_{1w}} in the corresponding quantile level.
#' @param b Int. The block size for subsampling. If \code{b=NA}, \eqn{b==\sqrt{length(Y)}}.
#'
#' @return A list of test results.
#' \itemize{
#' \item stat_CvM: the CvM test statistic
#' \item stat_b_CvM: the CvM test statistics in each step of subsampling
#' \item p_value: \eqn{p}-value of the CvM test
#' \item information: summary information
#' }
#' @export
#'
const_test <- function(Y,w,tau_multi,parm_multi,Omega_1_multi,b=NA){

  N <- length(Y)
  K <- length(tau_multi)

  # test statistic
  stat_CvM <- N*mean((parm_multi[,3]-mean(parm_multi[,3]))^2)

  # subsampling method for p-value
  z_tau_k <- function(parm,Y,w,tau,Omega_1){
    N <- length(Y)
    q <- matrix(0,nrow = N,ncol = 3)
    q[,1] <- 1
    beta_2 <- sapply(1:(N-1), function(x) parm[3]^(x-1))
    q[2:N,2] <- arch_fft(cst = 0,epsilon = Y[1:(N-1)],lambda = beta_2)
    beta_3 <- sapply(2:(N-1), function(x) (x-1)*parm[3]^(x-2))
    q[3:N,3] <- parm[2]*arch_fft(cst = 0,epsilon = Y[1:(N-2)],lambda = beta_3)

    eta <- c(0,rep(NA,N-1))
    eta[2:N] <- tau-(Y[2:N]-(parm[1]+parm[2]*q[2:N,2])<=0)

    q[1:N,1] <- w[1:N]*eta[1:N]
    q[2:N,2] <- q[2:N,2]*w[2:N]*eta[2:N]
    q[3:N,3] <- q[3:N,3]*w[3:N]*eta[3:N]

    z <- solve(Omega_1,tol=1e-100)%*%t(q)
    return(z)
  }

  z3_multi <- array(NA,dim = c(K,N))
  for(k in 1:K){
    z3_multi[k,] <- t(z_tau_k(parm_multi[k,],Y,w,tau_multi[k],Omega_1_multi[k,,]))[,3]
  }

  if(is.na(b)){
    b <- floor(sqrt(N))
  }
  B_n <- N-b

  beta_multi <- apply(z3_multi,1,mean)

  stat_b_CvM <- NA
  length(stat_b_CvM) <- B_n
  for(i in 1:B_n){
    z3_multi_b <- z3_multi[,i:(i+b)]
    beta_multi_b <- apply(z3_multi_b,1,mean)
    beta_stand <- beta_multi_b-mean(beta_multi_b)

    stat_b_CvM[i] <- b*mean(beta_stand^2)
  }
  p_value <- mean(stat_b_CvM>stat_CvM)
  return(list(
    "stat_CvM"=stat_CvM,
    "stat_b_CvM"=stat_b_CvM,
    "p_value"=p_value,
    "information"=paste("The value of CvM test statistic is ",round(stat_CvM,3),";The p value is ",round(p_value,3),".",sep = "")
  ))
}
