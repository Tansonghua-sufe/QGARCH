#' Rolling forecasting for conditional quantiles based on self-weighted QR
#'
#' One-step-ahead conditional quantile forecast based on self-weighted QR using a rolling forecast procedure.
#'
#' @details
#' We begin with the forecast origin \eqn{t_0=N_{train}+1}, and obtain the fitted quantile GARCH(1,1) model using the data from the beginning to the forecast origin (exclusive).
#' For each fitted model, we calculate the one-step-ahead conditional quantile forecast for the next trading day by  \eqn{\widetilde{Q}_{\tau}(y_{t_0}|\mathcal{F}_{n_0})=\widetilde{\omega}_{wn_0}(\tau)+\widetilde{\alpha}_{1wn_0}(\tau)\sum_{j=1}^{n_0}\left(\widetilde{\beta}_{1wn_0}(\tau)\right)^{j-1}|y_{N_{train}-j}|} based on the self-weighted QR.
#' We then advance the forecast origin by one and repeat the estimation and forecasting until all data are utilized.
#'
#'
#' @param data Vector. Data.
#' @param N_train Int. The size of rolling window.
#' @param fixTau Vector. Multiple quantile levels.
#' @param seed Double. Select random seed for optimization.
#'
#' @return Matrix with \code{length(data)-N_train} rows and \code{length(fixTau)} columns.
#' Each columns is the conditional quantile forecast result.
#' @export
#'
#'
VaR_forecasting_QR <- function(data,
                                N_train,
                                fixTau = c(0.005,0.010,0.05,0.95,(1-0.010),(1-0.005)),
                                seed=1234
){

  init_GARCH <- Init_par(data,fixTau)
  N <- length(data)
  N_fore <- N-N_train

  qt_record <- array(dim = c(N_fore,length(fixTau)))

  fun_parallel <- function(i){
    Y_train <- data[i:(N_train+i-1)]
    w <- weight_function_HeYi2021_cpp(Y = Y_train,C = quantile(Y_train,0.95))
    w <- w/w[1]
    VaR_fore <- array(dim = length(fixTau))
    for(tau_index in 1:length(fixTau)){
      tau <- fixTau[tau_index]
      par_QR <- c(init_GARCH$GARCH_par[1]/(1-init_GARCH$GARCH_par[3])*init_GARCH$Q_tau[tau_index],init_GARCH$GARCH_par[2]*init_GARCH$Q_tau[tau_index],init_GARCH$GARCH_par[3])
      result_QR <- fit1_optim(par = par_QR,Y = Y_train,w = w,tau = tau,lower=c(NA,NA,1e-3),upper=c(NA,NA,1-1e-3),seed=seed)
      VaR_fore[tau_index] <- tail(q_y(result_QR$par,Y_train),1)
    }
    return(VaR_fore)
  }
  clnum<-detectCores()
  cl <- makeCluster(getOption("cl.cores", clnum))
  varlist <- c("data","N_train","fixTau","N","N_fore","seed","init_GARCH",
               "Init_par","weight_function_HeYi2021_cpp","fit1_optim","q_y",
               "Loss_QR","Loss_QR_gr","fit1_optim_grid")
  clusterEvalQ(cl,{library(rugarch)})
  clusterExport(cl = cl,envir=environment(),varlist = varlist)
  clusterSetRNGStream(cl,123)
  SEQ <- 1:N_fore
  qt_record <- t(parSapply(cl,SEQ,fun_parallel))
  stopCluster(cl)
  gc()

  return(qt_record)
}

#' Rolling forecasting for conditional quantiles based on self-weighted CQR
#'
#' One-step-ahead conditional quantile forecast based on using a rolling forecast procedure.
#'
#' @details
#' The framework is similar to \code{VaR_forecasting_QR}, see more details in \code{VaR_forecasting_QR}.
#' Moreover, since the self-weighted CQR needs to choose an optimal \eqn{h} in advance,
#' we divide the dataset into the training set with size \code{N_train}, validation set with size \code{N_val} and
#' test set with size \code{length(data)-N_train-N_val}, and choose the optimal h that minimizes the check loss in the validation set.
#'
#'
#' @param data Vector. Data.
#' @param N_train Int. The size of rolling window.
#' @param N_val Int. The size of validation set.
#' @param fixTau Vector. Multiple quantile levels.
#' @param H Vector. Discrete points for grid search.
#' @param seed Double. Select random seed to generate initial value for optimization.
#'
#' @return Matrix with \code{length(data)-N_train-N_val} rows and \code{length(fixTau)} columns.
#' Each column saves the conditional quantile forecasts at a specific quantile level for the test set.
#' @export
VaR_forecasting_CQR <- function(data,
                                N_train,
                                N_val,
                                fixTau = c(0.005,0.010,0.05,0.95,(1-0.010),(1-0.005)),
                                H = 1:10/100,
                                seed=1234
){

  init_GARCH <- Init_par(data,fixTau)
  N <- length(data)
  N_fore <- N-N_train-N_val

  qt_record <- array(dim = c(N_fore+N_val,length(fixTau),length(H)))

  for(h_index in 1:length(H)){
    h <- H[h_index]
    # =======================================
    fun_parallel <- function(i){
      Y_train <- data[i:(N_train+i-1)]

      w <- weight_function_HeYi2021_cpp(Y = Y_train,C = quantile(Y_train,0.95))
      w <- w/w[1]
      VaR_fore <- array(dim = length(fixTau))
      for(tau_index in 1:length(fixTau)){
        tau <- fixTau[tau_index]
        if(tau<0.5){
          com_tau <- seq(from = tau,to = tau+h,length.out = 19)
        }else{
          com_tau <- seq(from = tau-h,to = tau,length.out = 19)
        }

        par_CQR <- c(init_GARCH$GARCH_par[1]/(1-init_GARCH$GARCH_par[3]),init_GARCH$GARCH_par[2],init_GARCH$GARCH_par[3],-0.1)
        result_CQR <- fit2_optim(par = par_CQR,Y = Y_train,w = w,tau = com_tau,seed=seed)
        VaR_fore[tau_index] <- tail(q_y(g_tau(result_CQR$par,tau),Y_train),1)
      }
      return(VaR_fore)
    }
    clnum<-detectCores()
    cl <- makeCluster(getOption("cl.cores", clnum))
    varlist <- c("data","N","N_train","N_val","N_fore","fixTau","h","seed","init_GARCH",
                 "Init_par","weight_function_HeYi2021_cpp","fit2_optim","q_y","g_tau",
                 "Loss_CQR","Loss_CQR_gr","fit2_optim_grid"
                 )
    clusterEvalQ(cl,{library(rugarch)})
    clusterExport(cl = cl,envir=environment(),varlist = varlist)
    clusterSetRNGStream(cl,123)
    SEQ <- 1:(N_fore+N_val)
    qt_record[,,h_index] <- t(parSapply(cl,SEQ,fun_parallel))
    stopCluster(cl)
    gc()
    # ===================================================
  }

  # CV to choose h
  optim_h <- array(dim = c(length(fixTau)))
  qt_CQR_opt <- array(dim = c(N_fore,length(fixTau)))
  for(tau_index in 1:length(fixTau)){
    tau <- fixTau[tau_index]
    check_loss <- apply(qt_record[1:N_val,tau_index,1:length(H)],2,function(x) sum(check_function(Y[(N_train+1):(N_train+N_val)]-x,tau),na.rm = F))
    optim_h[tau_index] <- H[which.min(check_loss)]
    qt_CQR_opt[,tau_index] <- qt_record[(N_val+1):(N_val+N_fore),tau_index,which.min(check_loss)]
  }
  return(qt_CQR_opt)
}
