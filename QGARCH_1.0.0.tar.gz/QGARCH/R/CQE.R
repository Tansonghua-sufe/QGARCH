#' Loss function for self-weighted QR estimation
#'
#' @param parm Vector. Parameter vector (3-dim), i.e. \eqn{(\omega(\tau),\alpha_1(\tau),\beta_1(\tau))^\prime}.
#' @param Y Vector. Data.
#' @param w Vector. Self-weights.
#' @param tau Double. Specific quantile level.
#'
#' @return Double. The value of the loss function for self-weighted QR estimation given a parameter vector.
#' @export
#

Loss_QR <- function(parm,Y,w,tau){
  N <- length(Y)
  q <- arch_fft(cst = parm[1],
                epsilon = Y[1:(N-1)],
                lambda = parm[2]*parm[3]^(0:(N-2)))
  l <- check_function(Y[2:N]-q,tau)

  lw <- w[2:N]*l

  return(sum(lw)+w[1]*check_function(Y[1]-parm[1],tau))
}



#' Gradient of the loss function for self-weighted QR estimation
#'
#' @param parm Vector. Parameter vector (3-dim), i.e. \eqn{(\omega(\tau),\alpha_1(\tau),\beta_1(\tau))^\prime}.
#' @param Y Vector. Data.
#' @param w Vector. Self-weights.
#' @param tau Double. Specific quantile level.
#'
#' @return Vector. The vector of the gradient of loss function for self-weighted QR estimation given a parameter vector.
#' @export
#

Loss_QR_gr <- function(parm,Y,w,tau){

  N <- length(Y)
  beta_c <- parm[3]^((1-1):(N-1-1))
  q <- arch_fft(cst = 0,epsilon = Y[1:(N-1)],lambda = beta_c[1:(N-1)])
  l <- tau-1*(Y[2:N]-parm[1]-parm[2]*q < 0)
  lw <- -w[2:N]*l
  lw <- c(-w[1]*psi_function(Y[1]-parm[1],tau),lw)

  gr_M <- matrix(0,nrow = N,ncol = 3)
  gr_M[,1] <- 1

  gr_M[2:N,2] <- q

  beta_2 <- parm[2]*(2:N-1)*parm[3]^(2:N-2)
  gr_M[3:N,3] <- arch_fft(cst = 0,epsilon = Y[1:(N-1)],lambda = beta_2[1:(N-1)])[1:(N-2)]
  gr <- c(t(lw)%*%gr_M)

  return(gr)
}

#' An optimization function of self-weighted QR estimation given fixed initial value.
#'
#' This function provide an optimization function of self-weighted QR with a fixed initial value.
#' Either method, derivative optimization using \code{stats::optim()} or derivative-free optimization using \code{dfoptim::hjkb()}, can be used.
#' To avoid error or non-convergence in optimization, we add an innovation to the initial value and re-optimize this problem.
#' If the optimization fails on the fixed initial value,
#' a more complicated optimization function \code{fit1_optim_grid} based on greedy search.
#'
#' @param par Vector. Initial value for optimization.
#' @param Y Vector. Data.
#' @param w Vector. Self-weights.
#' @param tau Double. Specific quantile level.
#' @param lower Vector. Lower bound for parameter. The default value is \code{c(NA,NA,1e-3)}.
#' @param upper Vector. Upper bound for parameter. The default value is \code{c(NA,NA,1-1e-3)}.
#' @param method Character. If \code{method="optim"}, derivative optimization by \code{stats::optim()} is used. If \code{method="dfoptim"}, derivative-free optimization by \code{dfoptim::hjkb()} is used.
#' @param iter_max_1 Int. If the optimization function does not converge or the parameter is at the boundary, then re-optimize. Maximum number of repetitions of this step is \code{iter_max_1}.
#' @param iter_max_2 Int. If the condition in \code{iter_max_1} cannot be satisfied, then relax the boundary condition and estimate again. Maximum number of repetitions of this step is \code{iter_max_2-iter_max_1}.
#' @param seed Double. Random seed is used to generate an innovation to perturb the initial value.
#'
#' @note
#' 1. The selection of initial values.
#'
#' Since the QGARCH model is extended from the classical GARCH model, the initial value can be chosen based on GARCH model. Specifically,
#' \itemize{
#' \item Estimate the parameters of GARCH(1,1) model (2.1) with \eqn{r_t=\sqrt{|y_t|}\left(sgn(y_t)\right)} using Gaussian QMLE and \eqn{Q_\tau(\eta_t)} using empirical quantile of \eqn{\hat{\eta}_t} based on package \code{rugarch}.
#' \item The initial value can be chosen as \eqn{\left(\frac{\hat{a}_0}{1-\hat{b}_1}\hat{Q}_\tau(\varepsilon_t),\hat{a}_1\hat{Q}_\tau(\varepsilon_t),\hat{b}_1\right)}, where \eqn{\hat{\varepsilon}_t=\hat{\eta}_t^2sgn(\hat{\eta}_t)}.
#' }
#'
#' 2. The necessity of random seed.
#'
#' To avoid error or non-convergence in optimization, we add an innovation to the initial value and re-optimize this problem, the random seed is set for reproducible results.
#'
#' @return A list of optimization results returned from the \code{optim()} or \code{hjkb()} function.
#' @export
#'
fit1_optim <-function(par=NULL,Y,w,tau,lower=c(NA,NA,1e-3),upper=c(NA,NA,1-1e-3),method="optim",iter_max_1=10,iter_max_2=20,seed=1234){
  if(!is.na(seed)){
    set.seed(seed)
  }

  if(is.null(par)){
    init_GARCH <- Init_par(Y = Y,fixTau = tau)
    par <- c(init_GARCH$GARCH_par[1]/(1-init_GARCH$GARCH_par[3])*init_GARCH$Q_tau,init_GARCH$GARCH_par[2]*init_GARCH$Q_tau,init_GARCH$GARCH_par[3])
  }

  if(method=="dfoptim"){
    fit0 <- try(hjkb(par = par,fn = Loss_QR,Y=Y,w=w,tau=tau,lower = lower,upper=upper),silent = T)
  }else{
    fit0 <- try(optim(par = par,fn = Loss_QR,gr = Loss_QR_gr,Y=Y,w=w,tau=tau,method = "L-BFGS-B",lower = lower,upper=upper),silent = T)
  }
  k <- 0
  convergence <- 0
  if("try-error"%in% class(fit0)){
    convergence <- 1
  }else{
    if(fit0$convergence!=0 | any(c(fit0$par[3]<=lower[3],fit0$par[3]>=upper[3]))){
      convergence <- 1
    }
  }
  while (convergence!=0 & k<iter_max_1){
    k <- k+1
    if(method=="dfoptim"){
      fit0 <- try(hjkb(par = par+runif(3,-0.1,0.1),fn = Loss_QR,Y=Y,w=w,tau=tau,lower = lower,upper=upper),silent = T)
    }else{
      fit0 <- try(optim(par = par+runif(3,-0.1,0.1),fn = Loss_QR,gr = Loss_QR_gr,Y=Y,w=w,tau=tau,method = "L-BFGS-B",lower = lower,upper=upper),silent = T)
    }
    convergence <- 0
    if("try-error"%in% class(fit0)){
      convergence <- 1
    }else{
      if(fit0$convergence!=0 | any(c(fit0$par[3]<=lower[3],fit0$par[3]>=upper[3]))){
        convergence <- 1
      }
    }
  }

  while (convergence!=0 & k<iter_max_2){
    k <- k+1
    if(method=="dfoptim"){
      fit0 <- try(hjkb(par = par+runif(3,-0.1,0.1),fn = Loss_QR,Y=Y,w=w,tau=tau,lower = lower,upper=upper),silent = T)
    }else{
      fit0 <- try(optim(par = par+runif(3,-0.1,0.1),fn = Loss_QR,Y=Y,w=w,tau=tau,method = "L-BFGS-B",lower = lower,upper=upper),silent = T)
    }
    convergence <- 0
    if("try-error"%in% class(fit0)){
      convergence <- 1
    }
  }

  if(convergence!=0){fit0 <- fit1_optim_grid(Y = Y,w = w,tau = tau)}
  names(fit0$par) <- paste(c("omega","alpha1","beta1"),"(",tau,")",sep = "")
  return(fit0)
}

#' An optimization function of self-weighted QR given multiple initial values
#'
#' This function extends the optimization function \code{fit1_optim()} given with a single initial value to multiple initial values.
#' The method is based on greedy algorithm. In this framework, we start by listing all the possible parameter values with interval \code{1/D}.
#' Then the loss function is evaluated at all points, and the points with the least loss are selected as the starting points for our optimization.
#'
#'
#' @param Y Vector. Data.
#' @param w Vector. Self-weights.
#' @param tau Double. Specific quantile level.
#' @param lower Vector. Lower bound for parameter. The default value is \code{c(NA,NA,1e-3)}.
#' @param upper Vector. Upper bound for parameter. The default value is \code{c(NA,NA,1-1e-3)}.
#' @param D Int. \code{1/D} is the interval for partition. The default value is 10.
#' @param num_best Int. The number of the selected points. The default value is 10.
#'
#' @return A list of optimization results returned from the \code{optim()} or \code{hjkb()} function.
#' @export
#'
fit1_optim_grid <-function(Y,w,tau,lower=c(NA,NA,1e-3),upper=c(NA,NA,1-1e-3),D=10,num_best=10){

  beta <- rep(1:(D-1)/D,each = (D-1)^2)
  alpha <- rep(qnorm(rep(1:(D-1)/D,each = (D-1))),times = (D-1))
  omega <- qnorm(rep(1:(D-1)/D,times = (D-1)^2))

  par <- matrix(c(omega,alpha,beta),nrow = (D-1)^3,ncol = 3)
  loss_par <- apply(par,1,function(x) Loss_QR(parm=x,Y=Y,w=w,tau = tau))
  index1 <- order(loss_par)
  if(length(index1)>num_best){index1 <- index1[1:num_best]}

  fun <- function(x){
    k <- 0
    convergence <- 0
    fit0 <- try(optim(par = x,fn = Loss_QR,gr = Loss_QR_gr,Y=Y,w=w,method = "L-BFGS-B",tau = tau,lower = lower,upper=upper,),silent = T)
    if("try-error"%in%class(fit0)==T){
      return(NA)
    }else{
      return(fit0$value)
    }

  }

  l <- apply(par[index1,],1,fun)
  index2 <- which.min(l)

  fit0 <- optim(par = par[index1[index2],],fn = Loss_QR,gr = Loss_QR_gr,Y=Y,w=w,method = "L-BFGS-B",tau = tau,lower = lower,upper=upper)
  names(fit0$par) <- paste(c("omega","alpha1","beta1"),"(",tau,")",sep = "")
  return(fit0)
}


# Function to compute covariance matrix
#
# Given \eqn{f_{t-1}(F_{t-1}^{-1}(\tau))}, this function computes the covariance matrix.
#
# @param parm Vector. Parameter vector.
# @param Y Vector. Data.
# @param w Vector. Self-weights.
# @param tau Double. Specific quantile level.
# @param quantity Vector. \eqn{f_{t-1}(F_{t-1}^{-1}(\tau))}.
#
# @return A list including Omega_0 (3 \eqn{\times} 3 matrix), Omega_1 (3 \eqn{\times} 3 matrix), Sigma (3 \eqn{\times} 3 matrix)
#' @export
#'
Sigma_QR <- function(parm,Y,w,tau,quantity){
  N <- length(Y)
  q <- matrix(0,nrow = N,ncol = 3)
  q[,1] <- 1
  beta_2 <- sapply(1:(N-1), function(x) parm[3]^(x-1))
  q[2:N,2] <- arch_fft(cst = 0,epsilon = Y[1:(N-1)],lambda = beta_2)
  beta_3 <- sapply(2:(N-1), function(x) (x-1)*parm[3]^(x-2))
  q[3:N,3] <- parm[2]*arch_fft(cst = 0,epsilon = Y[1:(N-2)],lambda = beta_3)

  Omega_t <- apply(q,1,function(x) x%*%t(x))
  Omega_0 <- matrix(apply(Omega_t,1,function(x) mean(w^2*x)),nrow = 3,ncol = 3)
  Omega_1 <- matrix(apply(Omega_t,1,function(x) mean(w*quantity*x)),nrow = 3,ncol = 3)

  Sigma <- tau*(1-tau)*solve(Omega_1,tol=1e-100)%*%Omega_0%*%solve(Omega_1,tol=1e-100)

  return(list("Omega_0"=Omega_0,"Omega_1"=Omega_1,"Sigma"=Sigma))
}

#' Compute ASD and related covariances of QR estimation
#'
#' Compute ASD, \eqn{\Omega_{0w}}, \eqn{\Omega_{1w}} and \eqn{\Sigma_{w}} of QR estimation
#'
#' @param parm Vector. Parameter vector. \eqn{\left(\omega(\tau),\alpha_1(\tau),\beta_1(\tau)\right)^\prime}.
#' @param Y Vector. Data.
#' @param w Vector. Self-weights.
#' @param tau Double. Specific quantile level (\eqn{\tau}).
#' @param h_type Character (\code{"HS"} or \code{"B"}). The commonly used bandwidth types for \eqn{\ell} to estimate the asymptotic covariance \eqn{\Sigma_w(\tau)} at Theorem 3.3. The default value is "HS"
#'
#' @return A list of ASD and related covariances of QR estimation.
#' \itemize{
#' \item ASD: 3-dim vector. The asymptotic standard errors (ASD) of the corresponding parameter vector.
#' \item Omega_0: 3 \eqn{\times} 3 matrix. \eqn{\widetilde{\Omega}_{0 w}(\tau,\tau)=\frac{1}{n} \sum_{t=1}^n w_t^2 \dot{\widetilde{q}}_t\left(\widetilde{\boldsymbol{\theta}}_{w n}(\tau)\right) \dot{\widetilde{q}}_t\left(\widetilde{\boldsymbol{\theta}}_{w n}(\tau)\right)}.
#' \item Omega_1: 3 \eqn{\times} 3 matrix. \eqn{\widetilde{\Omega}_{1 w}(\tau)=\frac{1}{n} \sum_{t=1}^n \widetilde{f}_{t-1}\left(F_{t-1}^{-1}(\tau)\right) w_t \dot{\widetilde{q}}_t\left(\widetilde{\boldsymbol{\theta}}_{w n}(\tau)\right) \dot{\widetilde{q}}_t\left(\widetilde{\boldsymbol{\theta}}_{w n}(\tau)\right)}.
#' \item Sigma: 3 \eqn{\times} 3 matrix. \eqn{\widetilde{\Sigma}_w(\tau, \tau)=\tau(1-\tau) \widetilde{\Omega}_{1 w}^{-1}(\tau) \widetilde{\Omega}_{0 w}(\tau, \tau) \widetilde{\Omega}_{1 w}^{-1}(\tau)}.
#' }
#'
#' @export
ASD_QR <- function(parm,Y,w,tau,h_type="HS"){
  h <- h_compute(n = length(Y),tau = tau)
  h_used <- ifelse(h_type=="HS",h[2],h[1])

  parm_r <- fit1_optim(par=parm,Y=Y,w=w,tau=tau+h_used)$par
  parm_l <- fit1_optim(par=parm,Y=Y,w=w,tau=tau-h_used)$par

  quantity <- c(0,2*h_used/abs(q_y(parm_r,Y)-q_y(parm_l,Y))[-length(Y)])
  Cov <- Sigma_QR(parm = parm,Y = Y,w = w,tau = tau,quantity = quantity)
  ASD <- sqrt(diag(Cov$Sigma)/length(Y))
  names(ASD) <- paste(c("omega","alpha1","beta1"),"(",tau,")",sep = "")
  return(list(
    "ASD"=ASD,
    "Sigma"=Cov$Sigma,
    "Omega_0"=Cov$Omega_0,
    "Omega_1"=Cov$Omega_1
  ))
}
