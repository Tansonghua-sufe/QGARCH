#include <Rcpp.h>
using namespace Rcpp;

//' Self-weight function based on He & Yi (2021)
//'
//'
//'
//' @param Y Vector. Data.
//' @param C Double. Quantile of Y or |Y|.
//'
//' @export
//[[Rcpp::export]]
NumericVector weight_function_HeYi2021_cpp(NumericVector Y,double C){
  int N=Y.length(),t,i;
  NumericVector w(N);

  for(t=0;t<N;t++){
    for(i=1;i<=t;i++){
      w[t]+=exp(-pow(log(i),2))*((fabs(Y[t-i])<C)? 1:(fabs(Y[t-i])/C));
    }

    for(i=t+1;i<N;i++){
      w[t]+=exp(-pow(log(i),2))*1;
    }
    w[t] = pow(w[t],-3);
  }

  return w;
}

